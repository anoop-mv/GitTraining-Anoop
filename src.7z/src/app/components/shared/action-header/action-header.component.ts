import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-action-header',
  templateUrl: './action-header.component.html',
  styleUrls: ['./action-header.component.css']
})
export class ActionHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
