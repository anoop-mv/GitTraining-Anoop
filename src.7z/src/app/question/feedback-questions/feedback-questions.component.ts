import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-feedback-questions',
  templateUrl: './feedback-questions.component.html',
  styleUrls: ['./feedback-questions.component.css']
})
export class FeedbackQuestionsComponent implements OnInit {

  constructor() { }
  
  ngOnInit() {
  }
}
