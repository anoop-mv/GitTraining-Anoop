export interface Response {

    message     : string;
    httpStatus  : number;
}