export interface FeedbackOption {
    eventId     : string;
    employeeId  : string;
    choice      : string;
    status      : string;
}
