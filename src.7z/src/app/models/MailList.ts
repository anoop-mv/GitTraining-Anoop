export interface MailList {
    eventId     : string;
    employeeId  : string;
    volType     : string;
    category    : string;
}
