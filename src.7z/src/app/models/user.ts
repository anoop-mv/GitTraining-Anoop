export interface User {
    id      : string;
    name    : string;
    emailId : string;
    role    : string;
    isUserAuthentic: string
}
