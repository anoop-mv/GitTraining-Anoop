export interface FeedbackStatus {
    eventId         : string;
    employeeId      : string;
    emailStatus     : string;
    feedbackStatus  : string;
}
