export interface EventReportResponse{
    eventSummary:any,
    eventRating:Int16Array
}    