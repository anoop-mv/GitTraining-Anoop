export interface DashRpt {
    events: string;
    va: number;
    vn: number;
    vu: number;
}