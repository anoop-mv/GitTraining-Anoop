export interface Feedback {
    eventId     : string;
    employeeId  : string;
    score       : number;
    answer1     : string;
    answer2     : string;
    status      : string;
}
