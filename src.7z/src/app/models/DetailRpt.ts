export interface DetailRpt {
    event_id        : string;
    base_location   : string;
    beneficiary_name: string;
    event_date      : string;
    employee_id     : string;
    score           : string;
    answer1         : string;
    answer2         : string;
    choice          : String;
}