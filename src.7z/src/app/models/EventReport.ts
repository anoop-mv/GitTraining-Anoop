export interface EventReport{
/*
    name        : string;
    averageScore: number;*/
}