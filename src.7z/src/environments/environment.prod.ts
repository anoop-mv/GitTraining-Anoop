export const environment = {
  production: true,
  authServerUrl:    'http://localhost:8090/uaa/',
  feedbackServerUrl:'http://localhost:7093/feedback-server/'
};
